package com.nexusai.forex

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF020916)
private val Panel = Color(0xFF071A30)
private val Blue = Color(0xFF078CFF)
private val Cyan = Color(0xFF32E5FF)
private val Green = Color(0xFF00D6A0)
private val Red = Color(0xFFFF4969)
private val Muted = Color(0xFF91A9C5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@Composable
fun NexusApp() {
    var selected by remember { mutableStateOf("Beranda") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, secondary = Cyan, background = Night,
            surface = Panel, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF041326), contentColor = Cyan) {
                    val tabs = listOf(
                        "Beranda" to Icons.Default.Home,
                        "Carta" to Icons.Default.ShowChart,
                        "AI" to Icons.Default.Psychology,
                        "Watchlist" to Icons.Default.Star,
                        "Profil" to Icons.Default.Person
                    )
                    tabs.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan,
                                selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF0B3155),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    "Beranda" -> HomeScreen(onNavigate = { selected = it })
                    "Carta" -> ChartScreen()
                    "AI" -> AiScreen()
                    "Watchlist" -> WatchlistScreen()
                    else -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun AppHeader(subtitle: String = "FOREX SPOT TRADING") {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(
                Brush.linearGradient(listOf(Blue, Cyan)), RoundedCornerShape(12.dp)
            ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.AutoAwesome, null, tint = Night, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("NEXUS AI", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(subtitle, color = Cyan, fontSize = 10.sp, letterSpacing = 1.2.sp)
        }
        Icon(Icons.Default.NotificationsNone, null, tint = Cyan, modifier = Modifier.size(25.dp))
    }
}

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().background(Night),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item { AppHeader() }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text("Halo, Trader!", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Pasaran sedang aktif. Berikut ringkasan pasaran anda.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                NeonCard {
                    Text("EQUITY AKAUN (DEMO)", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("$10,000.00", fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Text("+2.45%  (+$245.00)", color = Green, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    MiniSparkline()
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    QuickAction("Analisis AI", Icons.Default.Psychology) { onNavigate("AI") }
                    QuickAction("Carta", Icons.Default.ShowChart) { onNavigate("Carta") }
                    QuickAction("Watchlist", Icons.Default.Star) { onNavigate("Watchlist") }
                }
                Spacer(Modifier.height(20.dp))
                SectionTitle("Pasaran Utama", "DATA DEMO")
                Spacer(Modifier.height(8.dp))
                MarketRow("🇺🇸", "EURUSD", "1.0845", "+0.17%", true)
                MarketRow("🇬🇧", "GBPUSD", "1.3012", "+0.20%", true)
                MarketRow("🇯🇵", "USDJPY", "149.32", "-0.28%", false)
                MarketRow("🟡", "XAUUSD", "2732.45", "+0.46%", true)
                MarketRow("🇦🇺", "AUDUSD", "0.6718", "-0.28%", false)
                Spacer(Modifier.height(12.dp))
                NeonCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = Cyan)
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text("Mod Demo", fontWeight = FontWeight.Bold)
                            Text("Harga dipaparkan ialah contoh UI, bukan harga pasaran langsung.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(title: String, tag: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        Text(tag, color = Cyan, fontSize = 10.sp)
    }
}

@Composable
fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .border(1.dp, Blue.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0A2340), Color(0xFF041124))),
                RoundedCornerShape(16.dp)
            )
            .padding(15.dp),
        content = content
    )
}

@Composable
fun MiniSparkline() {
    Canvas(Modifier.fillMaxWidth().height(36.dp)) {
        val pts = listOf(.82f,.70f,.78f,.57f,.63f,.49f,.56f,.31f,.39f,.19f,.27f,.08f)
        val step = size.width / (pts.size - 1)
        for (i in 0 until pts.lastIndex) {
            drawLine(
                Blue, Offset(i * step, pts[i] * size.height),
                Offset((i + 1) * step, pts[i + 1] * size.height), 3.dp.toPx(), StrokeCap.Round
            )
        }
    }
}

@Composable
fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).border(1.dp, Blue.copy(alpha = .55f), RoundedCornerShape(12.dp))
            .background(Panel, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 13.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun MarketRow(flag: String, pair: String, price: String, change: String, up: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 11.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(flag, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Text(pair, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(price, color = Color.White, fontSize = 12.sp)
        Spacer(Modifier.width(8.dp))
        Text(
            change, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.background(if (up) Color(0xFF075C54) else Color(0xFF6A2038), RoundedCornerShape(7.dp))
                .padding(horizontal = 7.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun ChartScreen() {
    LazyColumn(Modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(16.dp)) {
        item { AppHeader("CARTA PASARAN") }
        item {
            NeonCard {
                Text("🇺🇸  EURUSD", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("1.0845", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Text("+0.17%", color = Green, fontSize = 13.sp)
                }
                Text("PAPARAN DEMO • BELUM DISAMBUNG KE DATA LANGSUNG", color = Muted, fontSize = 9.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("M1", "M5", "M15", "H1", "H4", "D1").forEach {
                        Text(it, color = if (it == "H1") Color.White else Muted,
                            modifier = Modifier.background(if (it == "H1") Blue else Color(0xFF102A46), RoundedCornerShape(6.dp))
                                .padding(horizontal = 9.dp, vertical = 7.dp), fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(15.dp))
                CandleChart()
                Spacer(Modifier.height(14.dp))
                Text("RSI (14)     68.4", color = Cyan, fontSize = 12.sp)
                Text("MACD (12,26,9)     Menunggu data langsung", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Text("Integrasi TradingView akan ditambah pada langkah sambungan carta.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun CandleChart() {
    Canvas(Modifier.fillMaxWidth().height(245.dp).background(Color(0xFF041426), RoundedCornerShape(10.dp))) {
        for (i in 1..5) {
            val y = size.height * i / 6
            drawLine(Color(0xFF16314D), Offset(0f,y), Offset(size.width,y), 1.dp.toPx())
        }
        for (i in 1..7) {
            val x = size.width * i / 8
            drawLine(Color(0xFF16314D), Offset(x,0f), Offset(x,size.height), 1.dp.toPx())
        }
        val values = listOf(.72f,.64f,.70f,.55f,.60f,.49f,.58f,.43f,.51f,.35f,.42f,.28f,.39f,.22f,.31f,.18f,.29f,.37f,.25f,.32f)
        val w = size.width / (values.size * 1.7f)
        values.forEachIndexed { i, v ->
            val x = (i + .5f) * size.width / values.size
            val next = if (i < values.lastIndex) values[i + 1] else v + .04f
            val color = if (next < v) Green else Red
            val top = minOf(v, next) * size.height
            val bottom = maxOf(v, next) * size.height
            drawLine(color, Offset(x, top - 13), Offset(x, bottom + 13), 2.dp.toPx())
            drawRect(color, Offset(x - w/2, top), androidx.compose.ui.geometry.Size(w, maxOf(8f, bottom-top)))
        }
        drawLine(Cyan, Offset(0f, size.height*.36f), Offset(size.width, size.height*.36f), 1.5.dp.toPx())
    }
}

@Composable
fun AiScreen() {
    LazyColumn(Modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(16.dp)) {
        item { AppHeader("AI MARKET ANALYSIS") }
        item {
            NeonCard {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(86.dp).border(2.dp, Cyan, CircleShape).background(Color(0xFF082A4B), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Psychology, null, tint = Cyan, modifier = Modifier.size(52.dp))
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("NEXUS AI", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Cyan, letterSpacing = 2.sp)
                        Text("Pembantu analisis pasaran", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("EURUSD  •  KECENDERUNGAN DEMO", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Contoh ringkasan: harga sedang bergerak dalam julat. Tunggu pengesahan trend dan semak kalendar ekonomi sebelum membuat keputusan.", color = Color(0xFFD0E1F3), fontSize = 13.sp, lineHeight = 20.sp)
                Spacer(Modifier.height(14.dp))
                Text("Keyakinan AI: belum tersedia", color = Cyan, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Analisis ini ialah teks contoh sahaja. Sambungan model AI dan data pasaran diperlukan untuk analisis sebenar.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun WatchlistScreen() {
    LazyColumn(Modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(16.dp)) {
        item { AppHeader("WATCHLIST • DATA DEMO") }
        item { SectionTitle("Pasangan Pilihan", "5 SIMBOL") }
        item { Spacer(Modifier.height(8.dp)) }
        item { MarketRow("🇺🇸", "EURUSD", "1.0845", "+0.17%", true) }
        item { MarketRow("🇬🇧", "GBPUSD", "1.3012", "+0.20%", true) }
        item { MarketRow("🇯🇵", "USDJPY", "149.32", "-0.28%", false) }
        item { MarketRow("🟡", "XAUUSD", "2732.45", "+0.46%", true) }
        item { MarketRow("🇦🇺", "AUDUSD", "0.6718", "-0.28%", false) }
        item { Spacer(Modifier.height(12.dp)) }
        item {
            NeonCard {
                Text("Watchlist ini menggunakan angka contoh.", color = Muted, fontSize = 12.sp)
                Text("Sumber data harga akan disambungkan pada langkah seterusnya.", color = Cyan, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    LazyColumn(Modifier.fillMaxSize().background(Night), contentPadding = PaddingValues(16.dp)) {
        item { AppHeader("PROFIL & TETAPAN") }
        item {
            NeonCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, null, tint = Cyan, modifier = Modifier.size(54.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Trader Nexus", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Akaun Demo", color = Cyan, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            listOf(
                Icons.Default.Security to "Pengurusan Risiko",
                Icons.Default.Notifications to "Notifikasi",
                Icons.Default.Mic to "Suara AI",
                Icons.Default.DarkMode to "Tema Gelap",
                Icons.Default.Language to "Bahasa Melayu",
                Icons.Default.HelpOutline to "Bantuan & Sokongan",
                Icons.Default.Info to "Tentang NEXUS AI"
            ).forEach { (icon, label) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .background(Panel, RoundedCornerShape(10.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, null, tint = Cyan)
                    Spacer(Modifier.width(12.dp))
                    Text(label, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}
