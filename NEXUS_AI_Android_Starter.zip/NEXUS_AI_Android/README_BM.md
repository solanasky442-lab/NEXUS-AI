# NEXUS AI — Projek Android (Starter)

Ini ialah projek asas Android asli menggunakan Kotlin + Jetpack Compose dengan tema gelap biru futuristik.

## Keadaan sekarang
- Navigasi Beranda, Carta, AI, Watchlist dan Profil berfungsi.
- Angka harga, baki akaun dan analisis yang dipaparkan ialah **data demo**.
- Belum ada data harga langsung, integrasi TradingView, backend AI, log masuk atau dagangan sebenar.
- Butang Beli/Jual dan pelaksanaan dagangan belum dibina; jangan gunakan angka demo untuk keputusan dagangan.

## Cara membuka dan membina APK
1. Pada komputer riba/PC, pasang Android Studio daripada laman rasmi Android Developers.
2. Ekstrak fail ZIP ini.
3. Android Studio > Open > pilih folder `NEXUS_AI_Android` (folder yang mengandungi `settings.gradle.kts`).
4. Benarkan Gradle Sync memuat turun komponen yang diperlukan.
5. Pilih Run untuk menguji pada emulator atau telefon Android dengan USB debugging.
6. Untuk APK debug: menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Selepas binaan berjaya, Android Studio akan menunjukkan pautan **locate** ke fail APK.

## Nota
- Projek ini menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35 dan Java 17.
- Sambungan internet diperlukan untuk memuat turun dependencies semasa sync/build.
- Jika Android Studio meminta SDK atau JDK, pasang/pilih versi yang disyorkan oleh Android Studio.
- Sebelum edaran awam, naik taraf dan semak versi dependencies, keselamatan, privasi, serta lesen data/carta.
